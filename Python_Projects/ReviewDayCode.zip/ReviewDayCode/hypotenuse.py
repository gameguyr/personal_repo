# -*- coding: utf-8 -*-
"""
Created on Wed Nov  7 18:50:50 2012

@author: therese
"""

#!/usr/bin/python
from __future__ import division


a = float(raw_input("length of side a:"))
b = float(raw_input("length of side b:"))

hyp = (a**2 + b**2)**(1/2)
print hyp

